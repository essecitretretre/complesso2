﻿using System;

namespace Casadei.Samuele._4H.Complesso2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Programma complesso di Samuele Casadei 4H");

            /*int somma = 0;

            Complesso z1 = new Complesso(5,3);
            Complesso z2 = new Complesso(6,4);

            Console.WriteLine("z1.reale, z1.immaginaria");
            Console.WriteLine("z2.reale, z2.immaginaria");
            
            z1.reale = 5;
            z1.immaginaria = 3;
            z2.reale = 6;
            z2.immaginaria = 4;

            somma = 
            Console.WriteLine("La somma è");*/

            double sommar = 0, sommai = 0, prodottor = 0, prodottoi = 0, quozienter = 0, quozientei = 0, sottrazioner = 0, sottrazionei = 0;
            double r1 = 5, r2 = 6;
            double i1 = 3, i2 = 7;

            Console.WriteLine("Primo numero:\n");
            Console.WriteLine("Parte reale {0}. Immaginaria {1} \n", r1, i1);
            Console.WriteLine("Secondo numero:\n");
            Console.WriteLine("Parte reale {0}. Immaginaria {1} \n", r2, i2);

            sommar = r1 + r2;
            sommai = i1 + i2;

            sottrazioner = r1 - r2;
            sottrazionei = i1 - i2;


            prodottor = r1 * r2;
            prodottoi = i1 * i2;

            quozienter = r1 / r2;
            quozientei = i1 / i2;



            Console.WriteLine("La somma della parte reale e': {0}. Quella immaginaria: {1}.", sommar, sommai);
            Console.WriteLine("La sottrazione della parte reale e': {0}. Quella della parte immaginaria: {1}.", sottrazioner, sottrazionei);
            Console.WriteLine("Il prodotto della parte reale e': {0}. Quello della parte immaginaria: {1}.", prodottor, prodottoi);
            Console.WriteLine("Il quoziente della parte reale e': {0}. Quello della parte immaginaria: {1}.", quozienter, quozientei);

        }



    }
    /*class Complesso
    {
        public int reale;
        public int immaginaria;

        public Complesso()
        {
            reale = 0;
            immaginaria = 0;
        }
        public Complesso(int a, int b)
        {
            reale = a;
            immaginaria = b;
        }
        public void somma(Complesso z1, Complesso z2)
        {
            reale = z1.reale + z2.reale;
            immaginaria = z1.immaginaria + z2.immaginaria;
        }
        public void sottrazione(Complesso z1, Complesso z2)
        {
            reale = z1.reale - z2.reale;
            immaginaria = z1.immaginaria - z2.immaginaria;
        }
        public void moltiplicazione(Complesso z1, Complesso z2)
        {
            reale = z1.reale * z2.reale;
            immaginaria = z1.immaginaria * z2.immaginaria;
        }
        public void divisione(Complesso z1, Complesso z2)
        {
            reale = z1.reale / z2.reale;
            immaginaria = z1.immaginaria / z2.immaginaria;
        }
        public void modulo(Complesso z1, Complesso z2)
        {
            modulo = math.sqrt ; 
        }
        public void fase(Complesso z1, Complesso z2)
        {

        }
        }*/

}






